import { useCallback, useEffect, useRef } from "react";
import * as faceapi from 'face-api.js';
import "./style.css";
import WebCam, { WebCamRef } from "../components/webcam";


type Props = {
  onClose: () => void;
  onCapture: (img: string) => void;
};

export default function Modal({ onCapture, onClose }: Props) {
  const webcamRef = useRef<WebCamRef>(null);

  useEffect(() => {
    const loadModels = async () => {
      await faceapi.nets.faceRecognitionNet.loadFromUri('/models');
      await faceapi.nets.faceLandmark68Net.loadFromUri('/models');
      await faceapi.nets.ssdMobilenetv1.loadFromUri('/models');
    };
    loadModels();
  }, []);

  const handlerOnClose = useCallback(() => {
    // const video = videoRef.current;
    // if (video && video.srcObject) {
    //   const stream = video.srcObject as MediaStream;
    //   stream.getTracks().forEach(track => track.stop());
    //   video.srcObject = null;
    // }
    onClose();
  }, [onClose]);

  const handleCapture = useCallback(() => {
    const screenshot = webcamRef.current?.capture()
    onCapture(String(screenshot));
    handlerOnClose()
  }, [onCapture, handlerOnClose])


  return (
    <div className="modal-overlay">
      <div className="modal-content">
        <button className="modal-close" onClick={handlerOnClose}>
          <svg xmlns="http://www.w3.org/2000/svg" x="0px" y="0px" width="24" height="24" viewBox="0,0,256,256">
            <g fill="none" fill-rule="nonzero" stroke="none" stroke-width="none" stroke-linecap="butt" stroke-linejoin="none" stroke-miterlimit="10" stroke-dasharray="" stroke-dashoffset="0" font-family="none" font-weight="none" font-size="none" text-anchor="none" ><path transform="scale(5.12,5.12)" d="M25,22.15625l15.84375,-15.84375l2.84375,2.84375l-15.84375,15.84375l15.9375,15.9375l-2.84375,2.84375l-15.9375,-15.9375l-15.96875,15.9375l-2.8125,-2.8125l15.9375,-15.96875l-15.84375,-15.84375l2.84375,-2.84375z" id="strokeMainSVG" fill="#ffffff" stroke="#ffffff" stroke-width="3" stroke-linejoin="round"></path><g transform="scale(5.12,5.12)" fill="#000000" stroke="none" stroke-width="1" stroke-linejoin="miter"><path d="M9.15625,6.3125l-2.84375,2.84375l15.84375,15.84375l-15.9375,15.96875l2.8125,2.8125l15.96875,-15.9375l15.9375,15.9375l2.84375,-2.84375l-15.9375,-15.9375l15.84375,-15.84375l-2.84375,-2.84375l-15.84375,15.84375z"></path></g></g>
          </svg>
        </button>
        <WebCam
        ref={webcamRef}
        />
        <div className="modal-actions">
          <button className="button-modal" onClick={handleCapture}>
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" width={24} height={24} stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" d="M6.827 6.175A2.31 2.31 0 0 1 5.186 7.23c-.38.054-.757.112-1.134.175C2.999 7.58 2.25 8.507 2.25 9.574V18a2.25 2.25 0 0 0 2.25 2.25h15A2.25 2.25 0 0 0 21.75 18V9.574c0-1.067-.75-1.994-1.802-2.169a47.865 47.865 0 0 0-1.134-.175 2.31 2.31 0 0 1-1.64-1.055l-.822-1.316a2.192 2.192 0 0 0-1.736-1.039 48.774 48.774 0 0 0-5.232 0 2.192 2.192 0 0 0-1.736 1.039l-.821 1.316Z" />
              <path stroke-linecap="round" stroke-linejoin="round" d="M16.5 12.75a4.5 4.5 0 1 1-9 0 4.5 4.5 0 0 1 9 0ZM18.75 10.5h.008v.008h-.008V10.5Z" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  )
}