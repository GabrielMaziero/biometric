import React, { useRef, useState } from 'react';
import * as faceapi from 'face-api.js';
import './style.css'
import Modal from '../modal';
import { useNavigate } from 'react-router-dom';

export default function FaceRegister() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [name, setName] = useState('');
  const [image, setImage] = useState<string | null>(null);
  const [showModal, setShowModal] = useState(false);
  const navigate = useNavigate();



  // const handleImageUpload = (e: any) => {
  //   const file = e.target.files[0];
  //   if (file) {
  //     setImage(URL.createObjectURL(file));
  //   }
  // };

  const handleCapture = async () => {
  if (!image || !name.trim()) {
    alert('Preencha o nome e tire uma foto');
    return;
  }

  const img = await faceapi.fetchImage(image);

    const detection = await faceapi
      .detectSingleFace(img)
      .withFaceLandmarks()
      .withFaceDescriptor();

    if (!detection) {
      alert('Nenhum rosto detectado');
      return;
    }

    let labeledDescriptors = [];

    try {
      const stored = localStorage.getItem('faces');
      labeledDescriptors = stored ? JSON.parse(stored) : [];
    } catch (err) {
      console.error('Erro ao carregar faces:', err);
      localStorage.removeItem('faces');
    }

    labeledDescriptors.push({
      label: name,
      descriptor: Array.from(detection.descriptor),
    });

    localStorage.setItem('faces', JSON.stringify(labeledDescriptors));
    alert('Rosto salvo com sucesso');
    setName('');
  };

  const handlerOnCapture = (img: string) => {
    setImage(img)
  }

  const handlerOnClose = () => {
    const video = videoRef.current;
    if (video && video.srcObject) {
      const stream = video.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      video.srcObject = null;
    }
    setShowModal(false);
  }

  return (
    <div className='container-register'>
      <svg onClick={() => navigate('/')} className='back-icon' xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" width={39} height={39} stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" d="M10.5 19.5 3 12m0 0 7.5-7.5M3 12h18" />
      </svg>
      <div className="content-register">
        <div className="container-image">
          <div className="drop-image">
            <h2>Upload your photo</h2>
            <div className="div-placeholder">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" width={39} height={39} stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" d="m2.25 15.75 5.159-5.159a2.25 2.25 0 0 1 3.182 0l5.159 5.159m-1.5-1.5 1.409-1.409a2.25 2.25 0 0 1 3.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 0 0 1.5-1.5V6a1.5 1.5 0 0 0-1.5-1.5H3.75A1.5 1.5 0 0 0 2.25 6v12a1.5 1.5 0 0 0 1.5 1.5Zm10.5-11.25h.008v.008h-.008V8.25Zm.375 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Z" />
              </svg>

              <p className='text-image-drop'>Click or drag and drop to upload your photo</p>
            </div>
            <div className="divider">OR</div>
            <div className="div-placeholder" onClick={() => setShowModal(true)}>
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" width={39} height={39} stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" d="M6.827 6.175A2.31 2.31 0 0 1 5.186 7.23c-.38.054-.757.112-1.134.175C2.999 7.58 2.25 8.507 2.25 9.574V18a2.25 2.25 0 0 0 2.25 2.25h15A2.25 2.25 0 0 0 21.75 18V9.574c0-1.067-.75-1.994-1.802-2.169a47.865 47.865 0 0 0-1.134-.175 2.31 2.31 0 0 1-1.64-1.055l-.822-1.316a2.192 2.192 0 0 0-1.736-1.039 48.774 48.774 0 0 0-5.232 0 2.192 2.192 0 0 0-1.736 1.039l-.821 1.316Z" />
                <path stroke-linecap="round" stroke-linejoin="round" d="M16.5 12.75a4.5 4.5 0 1 1-9 0 4.5 4.5 0 0 1 9 0ZM18.75 10.5h.008v.008h-.008V10.5Z" />
              </svg>
              <p className='text-image-drop'>Take your photo</p>
            </div>
          </div>
        </div>
        <div className="form">
          <div className="photo-container">
            {image ? (
              <img src={image} alt="Preview" className='photo' />
            ) : (
              <img src="/assets/placeholder-user.png" alt="Avatar" className='photo' />
            )}
          </div>
          <div className="input-container">
            <input className='userName' value={name} onChange={e => setName(e.target.value)} placeholder="Nome da pessoa" />
            <button className='userButton' onClick={handleCapture}>Cadastrar rosto</button>
          </div>
        </div>
      </div>
      {showModal && <Modal onCapture={handlerOnCapture} onClose={handlerOnClose} />}
    </div>
  );
}
