import './style.css'
import WebCam, { WebCamRef } from '../components/webcam';
import { useEffect, useRef, useState } from 'react';
import * as faceapi from 'face-api.js';
import { useNavigate } from 'react-router-dom';

export default function FaceDetected() {
  const webcamRef = useRef<WebCamRef>(null);
  // const canvasRef = useRef<HTMLCanvasElement>(null);
  const [name, setName] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const loadModels = async () => {
      await faceapi.nets.ssdMobilenetv1.loadFromUri('/models');
      await faceapi.nets.faceLandmark68Net.loadFromUri('/models');
      await faceapi.nets.faceRecognitionNet.loadFromUri('/models');
    };
    loadModels();
  }, []);

  useEffect(() => {
    const interval = setInterval(async () => {
      const imgSrc = webcamRef.current?.capture();
      if (!imgSrc) return;

      const img = await faceapi.fetchImage(imgSrc);
      const detection = await faceapi
        .detectSingleFace(img)
        .withFaceLandmarks()
        .withFaceDescriptor();

      if (!detection) {
        setName('')
        return
      };

      // const canvas = canvasRef.current;

      // if (!canvas) return;

      // canvas.width = img.width
      // canvas.height = img.height

      // faceapi.matchDimensions(canvas, {width: img.width, height: img.height})

      // const resized = faceapi.resizeResults(detection,
      //   {
      //     width: img.width,
      //     height: img.height
      //   }
      // )

      // faceapi.draw.drawDetections(canvas,resized)

      const stored = localStorage.getItem('faces');
      if (!stored) return;

      const labeledDescriptors = JSON.parse(stored).map((d: any) => {
        return new faceapi.LabeledFaceDescriptors(
          d.label,
          [new Float32Array(d.descriptor)]
        );
      });

      const faceMatcher = new faceapi.FaceMatcher(labeledDescriptors, 0.6);
      const bestMatch = faceMatcher.findBestMatch(detection.descriptor);

      if (bestMatch.label !== 'unknown') {
        setName(bestMatch.label);
      }
    }, 2000);

    return () => clearInterval(interval);
  }, []);


  return (
    <div className="container-detected">
      <svg onClick={() => navigate('/')} className='back-icon' xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" width={39} height={39} stroke="currentColor">
        <path stroke-linecap="round" stroke-linejoin="round" d="M10.5 19.5 3 12m0 0 7.5-7.5M3 12h18" />
      </svg>
      <div className="content-detected">
        <div className="camera-detected" style={{position:'absolute'}}>
          <WebCam
            ref={webcamRef}
            color={name ? '#009d2f' : '#FF0000' }
          />
          {/* <canvas ref={canvasRef} className='canvas-overlay'></canvas> */}
          <div className="name-detected">
            <p style={{ color: name && '#009d2f', fontSize: 20, fontWeight: 'bolder' }}>{name}</p>
          </div>
        </div>
      </div>
    </div>
  );
}