import { CSSProperties, forwardRef, useImperativeHandle, useRef } from "react";
import Webcam from "react-webcam"

const videoConstraints = {
  width: 460,
  height: 720,
  facingMode: "user"
};

export type WebCamRef = {
  capture: () => string | null;
};

type Props = {
  style?: CSSProperties
  color?: String
}

const WebCam = forwardRef<WebCamRef, Props>(({ style, color }, ref) => {
  const webcamRef = useRef<Webcam>(null);

  useImperativeHandle(ref, () => ({
    capture: () => webcamRef.current?.getScreenshot() || null
  }));

  const onUserMedia = (e: any) => {
    console.log(e);
  };
  return (
    <div style={{ display: 'flex', borderRadius: 504, overflow: 'hidden',
      border: `3px solid ${color ? color : ''}`, ...style
    }}>
      <Webcam
        style={{ width: 460, height: 720 }}
        ref={webcamRef}
        audio={false}
        screenshotFormat="image/jpeg"
        videoConstraints={videoConstraints}
        onUserMedia={onUserMedia}
      />
    </div>
  );
});

export default WebCam;