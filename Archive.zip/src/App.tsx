import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import FaceRegister from './modules/face-register';
import Layout from './layout';
import { Home } from './modules/home';
import FaceDetected from './modules/face-detected';

function App() {
  return (
    <BrowserRouter  >
      <Routes>
        <Route element={<Layout />}>
          <Route path='/' element={<Home />} />
          <Route path='/register' element={<FaceRegister />} />
          <Route path='/detected' element={<FaceDetected />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
