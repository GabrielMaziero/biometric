import { Outlet } from 'react-router-dom';
import './layout.css'; // ou styles.css

export default function Layout() {
  return (
    <div className="App">
      <Outlet />
    </div>
  );
}